const express = require('express');
const multer = require('multer');
const path = require('path');

const app = express();
const PORT = 3000;

// Configure storage for audio files
const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, 'uploads/'),
    filename: (req, file, cb) => cb(null, `${Date.now()}-${file.originalname}`)
});

const upload = multer({ storage });

// Serve static files for the web app
app.use(express.static(path.join(__dirname, 'public')));

// Handle audio upload
app.post('/upload', upload.single('audio'), (req, res) => {
    const fileURL = `http://localhost:${PORT}/uploads/${req.file.filename}`;
    res.json({ link: fileURL });
});

// Serve uploaded files
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Start server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
